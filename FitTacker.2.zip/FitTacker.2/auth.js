// ============================================================
// auth.js — Manejo de usuarios "tipo JSON" usando localStorage
// ============================================================
// Como esto es un sitio estático (sin servidor backend), no se
// puede leer/escribir un archivo .json real en disco. La forma
// estándar de simular eso en proyectos así es guardar un array
// de usuarios en formato JSON dentro de localStorage. Es decir,
// es literalmente una "base de datos" en JSON, solo que vive en
// el navegador en vez de un archivo físico.
//
// Mejora de seguridad: las contraseñas NUNCA se guardan en texto
// plano. Se hashean con SHA-256 antes de guardarse.
// ============================================================

const DB_KEY = "ft_users_db"; // clave donde se guarda el "json" de usuarios
const SESSION_KEY = "ft_session";

// --- Utilidades de hashing (SHA-256 via Web Crypto API) ---
async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

// --- Leer / escribir la "base de datos" JSON ---
function getUsers() {
  const raw = localStorage.getItem(DB_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveUsers(users) {
  localStorage.setItem(DB_KEY, JSON.stringify(users));
}

// --- Registro de usuario ---
async function registerUser({ username, email, password, confirmPassword }) {
  if (!username || !email || !password || !confirmPassword) {
    return { ok: false, error: "Completá todos los campos." };
  }
  if (password !== confirmPassword) {
    return { ok: false, error: "Las contraseñas no coinciden." };
  }
  if (password.length < 6) {
    return { ok: false, error: "La contraseña debe tener al menos 6 caracteres." };
  }

  const users = getUsers();
  const emailExists = users.some(u => u.email.toLowerCase() === email.toLowerCase());
  if (emailExists) {
    return { ok: false, error: "Ya existe una cuenta con ese correo." };
  }

  const passwordHash = await hashPassword(password);

  const newUser = {
    id: crypto.randomUUID(),
    username,
    email,
    passwordHash,
    createdAt: new Date().toISOString()
  };

  users.push(newUser);
  saveUsers(users);

  return { ok: true, user: newUser };
}

// --- Login de usuario ---
async function loginUser({ email, password }) {
  if (!email || !password) {
    return { ok: false, error: "Completá todos los campos." };
  }

  const users = getUsers();
  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (!user) {
    return { ok: false, error: "No existe una cuenta con ese correo." };
  }

  const passwordHash = await hashPassword(password);
  if (passwordHash !== user.passwordHash) {
    return { ok: false, error: "Contraseña incorrecta." };
  }

  return { ok: true, user };
}

// --- Sesión activa ---
function setSession(user) {
  // Guardamos solo lo necesario, nunca el hash de la contraseña
  const sessionData = {
    id: user.id,
    username: user.username,
    email: user.email
  };
  localStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));
}

function getSession() {
  const raw = localStorage.getItem(SESSION_KEY);
  return raw ? JSON.parse(raw) : null;
}

function logout() {
  localStorage.removeItem(SESSION_KEY);
}

// --- Protección de páginas internas (inicio_log, perfil, etc) ---
// Llamá a esta función al principio de cada página que requiera login.
function requireSession(redirectTo = "login_registro.html") {
  const session = getSession();
  if (!session) {
    window.location.href = redirectTo;
  }
  return session;
}
